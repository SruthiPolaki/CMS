﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tblfeedback
    {
        public long FeedbackAssessmentid { get; set; }
        public string FeedbackQuestion1 { get; set; }
        public string FeedbackQuestion2 { get; set; }
        public string FeedbackQuestion3 { get; set; }
        public string FeedbackQuestion4 { get; set; }
        public string FeedbackQuestion5 { get; set; }
        public string FeedbackQuestion6 { get; set; }
        public string FeedbackQuestion7 { get; set; }
        public string FeedbackQuestion8 { get; set; }
        public string FeedbackQuestion9 { get; set; }
        public string FeedbackQuestion10 { get; set; }
    }
}
