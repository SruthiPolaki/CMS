﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tblplancode
    {
        public Tblplancode()
        {
            Tblmember = new HashSet<Tblmember>();
        }

        public long PlanCode { get; set; }
        public string PlanDescription { get; set; }
        public string PlanCoverage1 { get; set; }
        public string PlanCoverage2 { get; set; }
        public string PlanCoverage3 { get; set; }
        public string PlanCoverage4 { get; set; }
        public string PlanCoverage5 { get; set; }

        public virtual ICollection<Tblmember> Tblmember { get; set; }
    }
}
