﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tblmember
    {
        public Tblmember()
        {
            Tblclaim = new HashSet<Tblclaim>();
        }

        public long MemberId { get; set; }
        public string MemberFirstname { get; set; }
        public string MemberLastname { get; set; }
        public int MemberAge { get; set; }
        public string MemberGender { get; set; }
        public DateTime MemberDob { get; set; }
        public long MemberContactnumber { get; set; }
        public long? MemberAltcontactnumber { get; set; }
        public string MemberEmailid { get; set; }
        public string MemberPassword { get; set; }
        public long MemberPlancode { get; set; }
        public DateTime MemberCoveragestartdate { get; set; }
        public DateTime MemberCoverageenddate { get; set; }
        public string MemberAddressline1 { get; set; }
        public string MemberAddressline2 { get; set; }
        public string MemberCity { get; set; }
        public string MemberState { get; set; }
        public long MemberZipcode { get; set; }
        public bool? MemberStatus { get; set; }
        public bool? MemberRejectedstatuis { get; set; }
        public string MemberRejMessage { get; set; }
        public string MemberRejClaimMessage { get; set; }
        public long? InsuranceAmount { get; set; }

        public virtual Tblplancode MemberPlancodeNavigation { get; set; }
        public virtual ICollection<Tblclaim> Tblclaim { get; set; }
    }
}
