﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ClaimsManagementEF.Models
{
    public partial class ClaimsManagementContext : DbContext
    {
        public ClaimsManagementContext()
        {
        }

        public ClaimsManagementContext(DbContextOptions<ClaimsManagementContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Tbladmin> Tbladmin { get; set; }
        public virtual DbSet<Tblclaim> Tblclaim { get; set; }
        public virtual DbSet<Tblfeedback> Tblfeedback { get; set; }
        public virtual DbSet<Tblmember> Tblmember { get; set; }
        public virtual DbSet<Tblplancode> Tblplancode { get; set; }
        public virtual DbSet<Tblsuperlogin> Tblsuperlogin { get; set; }
        public virtual DbSet<Tbluserfeedback> Tbluserfeedback { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=PCIN480252;database=ClaimsManagement;trusted_connection=yes");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<Tbladmin>(entity =>
            {
                entity.HasKey(e => e.AdminId)
                    .HasName("PK_tbl_admin");

                entity.ToTable("tbladmin");

                entity.Property(e => e.AdminId).HasColumnName("admin_id");

                entity.Property(e => e.AdminAge).HasColumnName("admin_age");

                entity.Property(e => e.AdminAltcontactnumber).HasColumnName("admin_altcontactnumber");

                entity.Property(e => e.AdminContactnumber).HasColumnName("admin_contactnumber");

                entity.Property(e => e.AdminDateofbirth)
                    .HasColumnName("admin_dateofbirth")
                    .HasColumnType("date");

                entity.Property(e => e.AdminEmailId)
                    .IsRequired()
                    .HasColumnName("admin_emailId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdminFirstname)
                    .IsRequired()
                    .HasColumnName("admin_firstname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdminGender)
                    .IsRequired()
                    .HasColumnName("admin_gender")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.AdminLastname)
                    .IsRequired()
                    .HasColumnName("admin_lastname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdminRejMessage)
                    .HasColumnName("admin_rej_message")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.AdminRejectedstatuis).HasColumnName("admin_rejectedstatuis");

                entity.Property(e => e.AdminStatus).HasColumnName("admin_status");
            });

            modelBuilder.Entity<Tblclaim>(entity =>
            {
                entity.HasKey(e => e.ClaimId)
                    .HasName("PK_tbl_claim");

                entity.ToTable("tblclaim");

                entity.Property(e => e.ClaimId).HasColumnName("claim_id");

                entity.Property(e => e.ClaimAmount).HasColumnName("claim_amount");

                entity.Property(e => e.ClaimApprovedamount).HasColumnName("claim_approvedamount");

                entity.Property(e => e.ClaimMemberid).HasColumnName("claim_memberid");

                entity.Property(e => e.ClaimProcessingdate)
                    .HasColumnName("claim_processingdate")
                    .HasColumnType("date");

                entity.Property(e => e.ClaimRejectionmsg)
                    .HasColumnName("claim_rejectionmsg")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimServicedate)
                    .HasColumnName("claim_servicedate")
                    .HasColumnType("date");

                entity.Property(e => e.ClaimStatus)
                    .HasColumnName("claim_status")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CliamSubmissiondate)
                    .HasColumnName("cliam_submissiondate")
                    .HasColumnType("date");

                entity.Property(e => e.MemberBills)
                    .HasColumnName("member_bills")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MemberProofId1)
                    .HasColumnName("member_proofId1")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MemberProofId2)
                    .HasColumnName("member_proofId2")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MemberProofname1)
                    .HasColumnName("member_proofname1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberProofname2)
                    .HasColumnName("member_proofname2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ClaimMember)
                    .WithMany(p => p.Tblclaim)
                    .HasForeignKey(d => d.ClaimMemberid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("claim_member_id");
            });

            modelBuilder.Entity<Tblfeedback>(entity =>
            {
                entity.HasKey(e => e.FeedbackAssessmentid)
                    .HasName("PK_tbl_feedback");

                entity.ToTable("tblfeedback");

                entity.Property(e => e.FeedbackAssessmentid).HasColumnName("feedback_assessmentid");

                entity.Property(e => e.FeedbackQuestion1)
                    .IsRequired()
                    .HasColumnName("feedback_question1")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion10)
                    .IsRequired()
                    .HasColumnName("feedback_question10")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion2)
                    .IsRequired()
                    .HasColumnName("feedback_question2")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion3)
                    .IsRequired()
                    .HasColumnName("feedback_question3")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion4)
                    .IsRequired()
                    .HasColumnName("feedback_question4")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion5)
                    .IsRequired()
                    .HasColumnName("feedback_question5")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion6)
                    .IsRequired()
                    .HasColumnName("feedback_question6")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion7)
                    .IsRequired()
                    .HasColumnName("feedback_question7")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion8)
                    .IsRequired()
                    .HasColumnName("feedback_question8")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FeedbackQuestion9)
                    .IsRequired()
                    .HasColumnName("feedback_question9")
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tblmember>(entity =>
            {
                entity.HasKey(e => e.MemberId)
                    .HasName("PK_tbl_member");

                entity.ToTable("tblmember");

                entity.Property(e => e.MemberId).HasColumnName("member_id");

                entity.Property(e => e.InsuranceAmount).HasColumnName("insurance_amount");

                entity.Property(e => e.MemberAddressline1)
                    .IsRequired()
                    .HasColumnName("member_addressline1")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.MemberAddressline2)
                    .IsRequired()
                    .HasColumnName("member_addressline2")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.MemberAge).HasColumnName("member_age");

                entity.Property(e => e.MemberAltcontactnumber).HasColumnName("member_altcontactnumber");

                entity.Property(e => e.MemberCity)
                    .IsRequired()
                    .HasColumnName("member_city")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberContactnumber).HasColumnName("member_contactnumber");

                entity.Property(e => e.MemberCoverageenddate)
                    .HasColumnName("member_coverageenddate")
                    .HasColumnType("date");

                entity.Property(e => e.MemberCoveragestartdate)
                    .HasColumnName("member_coveragestartdate")
                    .HasColumnType("date");

                entity.Property(e => e.MemberDob)
                    .HasColumnName("member_dob")
                    .HasColumnType("date");

                entity.Property(e => e.MemberEmailid)
                    .IsRequired()
                    .HasColumnName("member_emailid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberFirstname)
                    .IsRequired()
                    .HasColumnName("member_firstname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberGender)
                    .IsRequired()
                    .HasColumnName("member_gender")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.MemberLastname)
                    .IsRequired()
                    .HasColumnName("member_lastname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberPassword)
                    .IsRequired()
                    .HasColumnName("member_password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberPlancode).HasColumnName("member_plancode");

                entity.Property(e => e.MemberRejClaimMessage)
                    .HasColumnName("member_rej_claim_message")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.MemberRejMessage)
                    .HasColumnName("member_rej_message")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.MemberRejectedstatuis).HasColumnName("member_rejectedstatuis");

                entity.Property(e => e.MemberState)
                    .IsRequired()
                    .HasColumnName("member_state")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MemberStatus).HasColumnName("member_status");

                entity.Property(e => e.MemberZipcode).HasColumnName("member_zipcode");

                entity.HasOne(d => d.MemberPlancodeNavigation)
                    .WithMany(p => p.Tblmember)
                    .HasForeignKey(d => d.MemberPlancode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("member_plan_code");
            });

            modelBuilder.Entity<Tblplancode>(entity =>
            {
                entity.HasKey(e => e.PlanCode)
                    .HasName("PK_tbl_plan");

                entity.ToTable("tblplancode");

                entity.Property(e => e.PlanCode).HasColumnName("plan_code");

                entity.Property(e => e.PlanCoverage1)
                    .HasColumnName("plan_coverage1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanCoverage2)
                    .HasColumnName("plan_coverage2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanCoverage3)
                    .HasColumnName("plan_coverage3")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanCoverage4)
                    .HasColumnName("plan_coverage4")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanCoverage5)
                    .HasColumnName("plan_coverage5")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanDescription)
                    .HasColumnName("plan_description")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tblsuperlogin>(entity =>
            {
                entity.HasKey(e => e.SuplgSuperid)
                    .HasName("PK_tbl_fsuperlogin");

                entity.ToTable("tblsuperlogin");

                entity.Property(e => e.SuplgSuperid).HasColumnName("suplg_superid");

                entity.Property(e => e.SuplgPassword)
                    .IsRequired()
                    .HasColumnName("suplg_password")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.SuplgUsername)
                    .IsRequired()
                    .HasColumnName("suplg_username")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tbluserfeedback>(entity =>
            {
                entity.HasKey(e => e.UserfdId)
                    .HasName("PK_tbl_userfeedback");

                entity.ToTable("tbluserfeedback");

                entity.Property(e => e.UserfdId).HasColumnName("userfd_id");

                entity.Property(e => e.UserfdAssessmentdate)
                    .HasColumnName("userfd_assessmentdate")
                    .HasColumnType("date");

                entity.Property(e => e.UserfdRatingque1)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque1")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque10)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque10")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque2)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque2")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque3)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque3")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque4)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque4")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque5)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque5")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque6)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque6")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque7)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque7")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque8)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque8")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UserfdRatingque9)
                    .IsRequired()
                    .HasColumnName("userfd_ratingque9")
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });
        }
    }
}
