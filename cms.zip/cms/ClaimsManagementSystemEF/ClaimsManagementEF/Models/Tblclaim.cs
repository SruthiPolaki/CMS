﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tblclaim
    {
        public long ClaimId { get; set; }
        public long ClaimMemberid { get; set; }
        public DateTime? ClaimServicedate { get; set; }
        public DateTime? CliamSubmissiondate { get; set; }
        public DateTime? ClaimProcessingdate { get; set; }
        public string ClaimStatus { get; set; }
        public long? ClaimAmount { get; set; }
        public long? ClaimApprovedamount { get; set; }
        public string MemberProofname1 { get; set; }
        public string MemberProofname2 { get; set; }
        public string MemberProofId1 { get; set; }
        public string MemberProofId2 { get; set; }
        public string MemberBills { get; set; }
        public string ClaimRejectionmsg { get; set; }

        public virtual Tblmember ClaimMember { get; set; }
    }
}
