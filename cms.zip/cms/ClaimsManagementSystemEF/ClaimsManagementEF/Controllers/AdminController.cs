﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClaimsManagementEF.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClaimsManagementEF.Controllers
{
    [EnableCors("ClaimsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        ClaimsManagementContext claimsmanagement = new ClaimsManagementContext();
        Tbladmin admin = new Tbladmin();
        [Route("GetAllAdminDetails")]
        [HttpGet]
        public IActionResult GetAllAdminDetails()
        {
            return Ok(claimsmanagement.Tbladmin);
        }
        [Route("GetByMemberId/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetByMemberId(long id)
        {
            return Ok(claimsmanagement.Tblmember.Where(mem => mem.MemberId == id).FirstOrDefault());
        }

        [Route("GetByEmailId/{emailId}")]
        [HttpGet("{emailId}")]
        public IActionResult GetByEmailId(string emailId)
        {
            Tbladmin admin = claimsmanagement.Tbladmin.Where(ad => ad.AdminEmailId == emailId).FirstOrDefault();
            return Ok(admin);
        }

        [Route("AdminRegister")]
        [HttpPost]
        public IActionResult AdminRegister([FromBody] Tbladmin claimadmin)
        {
            Tbladmin admin = new Tbladmin();
            admin.AdminId = claimadmin.AdminId;
            admin.AdminFirstname = claimadmin.AdminFirstname;
            admin.AdminLastname = claimadmin.AdminLastname;
            admin.AdminAge = claimadmin.AdminAge;
            admin.AdminGender = claimadmin.AdminGender;
            admin.AdminDateofbirth = claimadmin.AdminDateofbirth;
            admin.AdminContactnumber = claimadmin.AdminContactnumber;
            admin.AdminAltcontactnumber = claimadmin.AdminAltcontactnumber;
            admin.AdminEmailId = claimadmin.AdminEmailId;
            admin.AdminStatus = false;
            admin.AdminRejectedstatuis = false;

            claimsmanagement.Tbladmin.Add(admin);
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Admin Registered" });
        }
        [Route("GetByMemberStatus")]
        [HttpGet]
        public IActionResult GetByMemberStatus()
        {


            return Ok(claimsmanagement.Tblmember.Where(user => user.MemberStatus == false && user.MemberRejectedstatuis == false));
        }
        [Route("AdminApproval/{adminId}/{status}")]
        [HttpPut("{adminId}/{status}")]

        public IActionResult AdminApproval(long adminId, bool status)
        {
            Tbladmin user = claimsmanagement.Tbladmin.Where(usr => usr.AdminId == adminId).FirstOrDefault();
            if (status == true)
            {
                user.AdminStatus = status;
                claimsmanagement.SaveChanges();
                return Ok(new { message = "Approved" });
            }
            else
            {
                return Ok(new { message = "Rejected" });
            }
        }

        [Route("MemberApproval/{memberId}/{status}")]
        [HttpPut("{memberId}/{status}")]

        public IActionResult MemberApproval(long memberId, bool status)
        {
            Tblmember user = claimsmanagement.Tblmember.Where(usr => usr.MemberId == memberId).FirstOrDefault();
            if (status == true)
            {
                user.MemberStatus = status;
                claimsmanagement.SaveChanges();
                return Ok(new { message = "Approved" });
            }
            else
            {
                return Ok(new { message = "Rejected" });
            }
        }

        //[Route("GetAllClaimDetails")]
        //[HttpGet]
        //public IActionResult GetAllClaimDetails()
        //{
        //    return Ok(claimsmanagement.Tblclaim);
        //}

        [Route("GetClaimByMemberId")]
        [HttpGet("{memberId}")]

        public IActionResult GetClaimByMemberId(long memberId)
        {
            List<Tblclaim> claimsList = new List<Tblclaim>();
            foreach (var item in claimsmanagement.Tblclaim.Where(user => user.ClaimMemberid == memberId))
            {
                claimsList.Add(item);
            }
            return Ok(claimsList);
        }
        [Route("MemberRejection/{memberId}/{status}/{message}")]
        [HttpPut("{memberId}/{status}/{message}")]
        public IActionResult MemberRejection(long memberId, bool status, string message)
        {
            Tblmember user = claimsmanagement.Tblmember.Where(mem => mem.MemberId == memberId).FirstOrDefault();
            if (status == false)
            {
                user.MemberRejectedstatuis = true;
                user.MemberRejMessage = message;
                claimsmanagement.SaveChanges();
                return Ok(new { message = "Rejected By Admin" });
            }
            return Ok(new { message = "Not Approved/Rejected By Admin" });
        }

        [Route("GetClaimDetails")]
        [HttpGet]
        public IActionResult GetClaimDetails()
        {
            Tblclaim claimdet = new Tblclaim();
            var claim = from c in claimsmanagement.Tblclaim.Where(cl => cl.ClaimMemberid == cl.ClaimMember.MemberId && cl.ClaimStatus != "Accepted" && cl.ClaimStatus != "Rejected")
                        select new
                        {
                            c.ClaimId,
                            c.ClaimMemberid,
                            c.ClaimMember.MemberFirstname,
                            c.ClaimMember.MemberLastname,
                            c.ClaimMember.MemberContactnumber,
                            c.ClaimAmount
                        };
            return Ok(claim);
        }

        [Route("GetMemberDetailsByClaimId/{ClaimId}/{MemberId}")]
        [HttpGet("{ClaimId}/{MemberId}")]
        public IActionResult GetMemberDetailsByClaimId(long ClaimId, long MemberId)
        {
            Tblclaim claimDetails = new Tblclaim();
            var memberDetails = from c in claimsmanagement.Tblclaim.Where(cl => cl.ClaimId == ClaimId && cl.ClaimMemberid == cl.ClaimMember.MemberId && cl.ClaimMemberid == MemberId)
                                select new
                                {
                                    c.ClaimId,
                                    c.ClaimMemberid,
                                    c.ClaimMember.MemberFirstname,
                                    c.ClaimMember.MemberLastname,
                                    c.ClaimMember.MemberDob,
                                    c.ClaimMember.MemberAge,
                                    c.ClaimMember.MemberContactnumber,
                                    c.ClaimStatus,
                                    c.ClaimMember.MemberAltcontactnumber,
                                    c.ClaimMember.MemberEmailid,
                                    c.ClaimMember.MemberGender,
                                    c.ClaimMember.MemberPlancode,
                                    c.ClaimMember.MemberCoveragestartdate,
                                    c.ClaimMember.MemberCoverageenddate,
                                    c.ClaimMember.InsuranceAmount,
                                    c.MemberProofname1,
                                    c.MemberProofname2,
                                    c.MemberProofId1,
                                    c.MemberProofId2,
                                    c.MemberBills,
                                    c.ClaimMember.MemberAddressline1,
                                    c.ClaimMember.MemberAddressline2,
                                    c.ClaimMember.MemberCity,
                                    c.ClaimMember.MemberState,
                                    c.ClaimMember.MemberZipcode,
                                    c.ClaimAmount
                                };
            return Ok(memberDetails);
        }
        [Route("ClaimApproval/{claimid}/{claimstatus}/{claimamount}")]
        [HttpPut("{claimid}/{claimstatus}/{claimamount}")]
        public IActionResult ClaimApproval(long claimid, string claimstatus, long claimamount)
        {
            Tblclaim user = claimsmanagement.Tblclaim.Where(mem => mem.ClaimId == claimid).FirstOrDefault();

            user.ClaimStatus = claimstatus;
            user.ClaimApprovedamount = claimamount;
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Accepted by admin " });
        }
        [Route("ClaimRejection/{claimid}/{claimstatus}/{message}")]
        [HttpPut("{claimid}/{claimstatus}/{message}")]
        public IActionResult ClaimRejection(long claimid, string claimstatus, string message)
        {
            Tblclaim user = claimsmanagement.Tblclaim.Where(mem => mem.ClaimId == claimid).FirstOrDefault();

            user.ClaimStatus = claimstatus;
            user.ClaimRejectionmsg = message;
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Rejected by admin " });
        }
        [Route("GetAllFeedbacks")]
        [HttpGet]
        public IActionResult GetAllFeedbacks()
        {
            return Ok(claimsmanagement.Tbluserfeedback);
        }

    }
}