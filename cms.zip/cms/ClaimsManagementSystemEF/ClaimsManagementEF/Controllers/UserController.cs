﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClaimsManagementEF.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClaimsManagementEF.Controllers
{
    [EnableCors("ClaimsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        ClaimsManagementContext claimsmanagement = new ClaimsManagementContext();
        [Route("AdminLogin")]
        [HttpPost]
        public IActionResult AdminLogin([FromBody] User user)
        {
            var userLogged = claimsmanagement.Tbladmin.Where(ad => ad.AdminEmailId == user.AdminEmailId && ad.AdminFirstname == user.AdminFirstname).FirstOrDefault();
            if (userLogged != null)
            {
                if (userLogged.AdminStatus == true)
                {
                    return Ok(new { Message = "Logged In Successfully", User = userLogged });
                }
                else
                {
                    return Ok(new { Message = "User not approved", User = userLogged });
                }
            }
            else
            {
                return Ok(new { message = "Invalid credentials" });
            }
        }

        [Route("MemberLogin")]
        [HttpPost]
        public IActionResult MemberLogin([FromBody] User user)
        {
            var userLogged = claimsmanagement.Tblmember.Where(mem => mem.MemberEmailid == user.MemberEmailId && mem.MemberPassword == user.MemberPassword).FirstOrDefault();
            if (userLogged != null)
            {
                if (userLogged.MemberStatus == true)
                {
                    return Ok(new { Message = "Logged In Successfully", User = userLogged });
                }
                else
                {
                    return Ok(new { Message = "User not approved", User = userLogged });
                }
            }
            else
            {
                return Ok(new { message = "Invalid credentials" });
            }
        }
        [Route("SuperUserLogin")]
        [HttpPost]
        public IActionResult SuperUserLogin([FromBody]User user)
        {

            var userLogged = claimsmanagement.Tblsuperlogin.Where(mem => mem.SuplgUsername == user.SuplgUsrname && mem.SuplgPassword == user.SuplgPassword).FirstOrDefault();
            if (userLogged != null)
            {
                return Ok(new { Message = "Logged In Successfully", User = userLogged });

            }
            else
            {
                return Ok(new { message = "Invalid credentials" });
            }
        }

    }
}