import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Member } from '../member/Member';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { Observable } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-claimrequest',
  templateUrl: './claimrequest.component.html',
  styleUrls: ['./claimrequest.component.css']
})
export class ClaimrequestComponent implements OnInit {
  memberId:number;
  id:number;
  memberDetail:Observable<Member>;
  ClaimForm:FormGroup;
  date = new Date()
  

  constructor(private formBuilder:FormBuilder,private activatedRoute:ActivatedRoute,private userService:UserService,private datepipe:DatePipe,private router:Router) { }
  

  ngOnInit() {
    //this.memberId = this.activatedRoute.snapshot.params['id'] as number
    console.log(this.userService.user)
    this.ClaimForm = this.formBuilder.group({
      // claimId:[''],
      claimMemberId:[this.userService.user['memberId']],
      memberEmailid:[this.userService.user['memberEmailid'],[Validators.required]],
      memberFirstname:[this.userService.user['memberFirstname'],[Validators.required]],
      memberLastname:[this.userService.user['memberLastname'],[Validators.required]],          
      memberContactnumber:[this.userService.user['memberContactnumber'],[Validators.required]], 
      claimAmount:['',[Validators.required, Validators.maxLength(12), Validators.pattern('^[0-9]+$')]],    
      memberProofname1:['',[Validators.required]],
      memberProofId1:['',[Validators.required]],
      memberProofname2:[''],
      memberProofId2:[''],
      memberBills:['',[Validators.required]]

    });
  }
  onClaimregclick()
  {
    console.log("onClaimregclick");
    this.userService.submit1 = true;
    this.userService.resubmit = false;
    let response = this.userService.onClaimSubmission(this.ClaimForm)
    response.subscribe(
      data =>{
        console.log(data['message'])
        this.router.navigateByUrl('/submitstatus/'+data['claimId']);
      },
      error => console.log(error)
    );

  }
}
