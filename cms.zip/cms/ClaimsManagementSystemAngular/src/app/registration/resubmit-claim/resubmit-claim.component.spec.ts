import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResubmitClaimComponent } from './resubmit-claim.component';

describe('ResubmitClaimComponent', () => {
  let component: ResubmitClaimComponent;
  let fixture: ComponentFixture<ResubmitClaimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResubmitClaimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResubmitClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
