import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { Member } from '../member/Member';

@Component({
  selector: 'app-resubmit-claim',
  templateUrl: './resubmit-claim.component.html',
  styleUrls: ['./resubmit-claim.component.css']
})
export class ResubmitClaimComponent implements OnInit {
  claimId:number;
  claimId2:number;
  id:number;
  submitForm:FormGroup
  memberDetail:Observable<Member>;
  
  date = new Date()

  constructor(private formBuilder:FormBuilder,private activatedRoute:ActivatedRoute,private userService:UserService,private datepipe:DatePipe,private router:Router) { }

  ngOnInit() {
    this.claimId = this.activatedRoute.snapshot.params['claimId'] as number
    this.userService.getResubmitEditClaimDetails(this.claimId).subscribe(
      data => {
        this.submitForm = data[0]
        console.log(this.submitForm)
        this.claimId2 = this.submitForm['claimId'];
        this.submitForm = this.formBuilder.group({
          
          claimId:[this.submitForm['claimId']],
          claimMemberId:[this.submitForm['claimMemberid']],
          memberEmailid:[this.submitForm['memberEmailid'],[Validators.required]],
          memberFirstname:[this.submitForm['memberFirstname'],[Validators.required]],
          memberLastname:[this.submitForm['memberLastname'],[Validators.required]],          
          memberContactnumber:[this.submitForm['memberContactnumber'],[Validators.required]], 
          claimAmount:[this.submitForm['claimAmount'],[Validators.required, Validators.maxLength(12), Validators.pattern('^[0-9]+$')]],    
          memberProofname1:[this.submitForm['memberProofname1'],[Validators.required]],
          memberProofId1:[this.submitForm['memberProofId1'],[Validators.required]],
          memberProofname2:[this.submitForm['memberProofname2']],
          memberProofId2:[this.submitForm['memberProofId2']],
          memberBills:[this.submitForm['memberBills'],[Validators.required]]
    
        });
      }
    )
   


  }

  onClaimreSubmitclick()
  {
    console.log("onClaimregclick");
    this.userService.submit1 = false;
    this.userService.resubmit = true;
    
    let response = this.userService.onClaimSubmissionEdit(this.submitForm,this.claimId2)
    response.subscribe(
      data =>{
        console.log(data['message'])
        this.router.navigateByUrl('/submitstatus/'+this.claimId2);
        
      },
      error => console.log(error)
    );

  }

}
