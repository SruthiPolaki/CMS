import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  admin = false;
  member = false;
  superUser = false;
  user
  submit1 = false;
  resubmit = false;
  baseUrl = "https://localhost:44367/api";

  constructor(private http:HttpClient, private router:Router) { }

  authenticate(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.post(this.baseUrl+"/user/AdminLogin",body,options)
  }
  authenticateMember(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.post(this.baseUrl+"/user/MemberLogin",body,options)
  }
  authenticateSuperuser(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    console.log(credentials);
    return this.http.post(this.baseUrl+"/user/SuperUserLogin",body,options)
  }
  requestClaimDetails():Observable<any[]>{
  
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get<any[]>(this.baseUrl+"/admin/GetClaimDetails",options)
  }
  requestMemberDetailsByClaimId(claimid:any,memberid:any){
    let data= claimid+"/"+memberid;
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get(this.baseUrl+"/admin/GetMemberDetailsByClaimId/"+data,options) 

  }
  getClaimStatus(memberid:any):Observable<any[]>{
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get<any[]>(this.baseUrl+"/member/GetByMemberId/"+memberid,options) 
  }

  getResubmitEditClaimDetails(id:number)
  {
    console.log("entered")
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get(this.baseUrl+"/member/ResubmitEditClaim/"+id,options)
  }
  requestAdminDetails():Observable<any[]>{
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get<any[]>(this.baseUrl+"/superAdmin/GetByAdminStatus",options)
  }
 
  viewMemberDetailsById(id:number){
    console.log("entered");
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' });
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/admin/GetByMemberId/"+id,options)
  }

  approveStatus(email:any, status:any)
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' });
    let options = { headers: header };
    return this.http.put(this.baseUrl+"/userInfo",options)
  }
  getAllClaimDetails():Observable<any[]>{
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' });
    let options = { headers: header };
    return this.http.get<any[]>(this.baseUrl+"/SuperAdmin/ClaimDetails",options)
  }
 
  requestDetails():Observable<any[]>{
    
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get<any[]>(this.baseUrl+"/admin/GetByMemberStatus",options)
  }
  memberDetails():Observable<any[]>{
    
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    // return this.http.post(this.baseUrl+"/auth",body,options)
    return this.http.get<any[]>(this.baseUrl+"/SuperAdmin/MemberDetails",options)
  }
  acceptMember(id:number,status:boolean):Observable<any[]>{
    let data =id+"/"+status;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.put<any[]>(this.baseUrl+"/admin/memberApproval/"+data,httpOptions);

  }
  onClaimRegister(id:number){
    let data = id;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.put<any[]>(this.baseUrl+"/admin/memberApproval/"+data,httpOptions);

  }
  onClaimSubmission(credentials:any){
    let body = JSON.stringify(credentials.value)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log("onClaimSubmission")
    console.log(body);
    return this.http.post(this.baseUrl+"/member/ClaimDetails/",body,httpOptions);
  }

  onClaimSubmissionEdit(credentials:any, id:number){
    let body = JSON.stringify(credentials.value)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log("onClaimSubmission")
    console.log(body);
    return this.http.put(this.baseUrl+"/member/ClaimDetailsEdit/"+id,body,httpOptions);
  }


  submitFeedback(credentials:any){
    console.log("submitFeedback")
    let body = JSON.stringify(credentials.value)
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
  
    return this.http.post(this.baseUrl+"/member/GiveFeedback/",body,httpOptions);
  }

 getResubmitClaimDetails(id:number){
  console.log("entered")
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
  let options = { headers: header }
  // return this.http.post(this.baseUrl+"/auth",body,options)
  return this.http.get(this.baseUrl+"/member/ResubmitClaim/"+id,options)
 }
  onClaimApproval(id:number,status:string,message:number)
  {
    let data =id+"/"+status+"/"+message;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.put(this.baseUrl+"/admin/ClaimApproval/"+data,httpOptions);
  }

  onClaimReject(id:number,status:string,message:string)
  {
    let data =id+"/"+status+"/"+message;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.put(this.baseUrl+"/admin/ClaimRejection/"+data,httpOptions);
  }

  viewAdminDetailsById(id:number){
    console.log("entered");
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' });
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/superAdmin/GetAdminById/"+id,options)
  }

rejectMember(id:number,status:boolean,message:string):Observable<any[]>{
let data=id+"/"+status+"/"+message;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
       
      })
    };
    return this.http.put<any[]>(this.baseUrl+"/admin/MemberRejection/"+data,httpOptions);
  }

  acceptAdmin(id:number,status:boolean):Observable<any[]>{
    let data =id+"/"+status;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.put<any[]>(this.baseUrl+"/SuperAdmin/AdminApproval/"+data,httpOptions);
  }

  rejectAdmin(id:number,status:boolean,message:string):Observable<any[]>{
    let data=id+"/"+status+"/"+message;
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
           
          })
        };
        return this.http.put<any[]>(this.baseUrl+"/SuperAdmin/adminRejection/"+data,httpOptions);
      }

   GetMemberDetailsById(id:number):Observable<any>{
    let data =id;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        
      })
    };
    console.log(id);
    return this.http.get<any>(this.baseUrl+"/member/GetByMemberId/"+data,httpOptions);
   }   

    
  logout(){
    
    this.admin = false
    this.member = false
    this.superUser = false
    this.router.navigateByUrl('/home')
  }


}













