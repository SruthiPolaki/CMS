import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { HttpClient } from 'selenium-webdriver/http';
import { Admin } from './admin/Admin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseUrl=environment.baseUrl+'admin';
  adminUrl=environment.baseUrl;
  adminApproval:boolean;

  constructor(private httpClient: HttpClient, private route: Router) { }
  // addAdmin(admin:Admin): Observable<Admin>
  // {
  //   console.log("FROM USER SERVICE -> " + admin)
  //   return this.httpClient.post<Admin>("https://localhost:44367/api/admin", admin,
  //     {
        
  //       headers:new HttpHeaders({
  //         'Content-Type': 'application/json',
          
  //       })
       
  //     });
    
  // }
}
