export interface Member
{
    memberId: number;
    memberFirstname:string;
    memberLastname:string;
    memberAge:number;
    memberGender: string;
    memberDob: Date;
    memberContactnumber: number;
    memberAltcontactnumber: number;
    memberEmailid: string;
    memberPassword: string;
    memberPlancode: number;
    memberCoveragestartdate:Date;
    memberCoverageenddate: Date;
    memberAddressline1: string;
    memberAddressline2:string;
    memberCity: string;
    memberState:string;
    memberZipcode:number;
    memberStatus:boolean;
    memberRejectedstatuis:boolean;
    memberRejMessage:string;
    memberRejClaimMessage:string;
    insuranceAmount:number;
}