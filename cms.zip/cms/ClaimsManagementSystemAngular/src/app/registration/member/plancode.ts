export interface PlanCode{
    planCode:Number;
    PlanDescription:string;
    PlanCoverage1:string;
    PlanCoverage2:string;
    PlanCoverage3:string;
    PlanCoverage4:string;
    PlanCoverage5:string;
}