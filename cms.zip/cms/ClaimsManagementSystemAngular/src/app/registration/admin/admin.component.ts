import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'appAdmin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  title = 'web-api-vrs-angular';
  data: Object;
  errorMessage: any;

  AdminForm:FormGroup;

  constructor(private formBuilder:FormBuilder,private http:HttpClient) { }
  

  ngOnInit() {
    this.AdminForm = this.formBuilder.group({
      adminid:[''],
      firstName:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      lastName:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      age:['',[Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]],
      gender:['',Validators.required],
      dob:['',Validators.required],
      contact:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      altcontact:['',[Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      emailid:['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
    });
  }
  

  }

