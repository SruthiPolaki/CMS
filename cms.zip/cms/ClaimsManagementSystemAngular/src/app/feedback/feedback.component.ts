import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../registration/user.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedbackQuestion:any
  FeedbackForm:FormGroup;

  
  constructor(private formBuilder:FormBuilder,private http:HttpClient,private userService:UserService) { }

  ngOnInit() {
    this.FeedbackForm = this.formBuilder.group({
      userfdRatingque1:[''],
      userfdRatingque2:[''],
      userfdRatingque3:[''],
      userfdRatingque4:[''],
      userfdRatingque5:[''],
      userfdRatingque6:[''],
      userfdRatingque7:[''],
      userfdRatingque8:[''],
      userfdRatingque9:[''],
      userfdRatingque10:[''],
      // userfdAssessmentdate:['']
    });
 
   }

onSubmit(){
  console.log("entered")
  console.log(this.FeedbackForm.value);
  this.userService.submitFeedback(this.FeedbackForm).subscribe(
    data => {
      console.log(data)
    }
  );
  // console.log(this.feedbackQuestion)
}

}
