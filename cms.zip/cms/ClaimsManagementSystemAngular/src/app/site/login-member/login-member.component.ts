import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/registration/user.service';
import { AuthGaurdService } from 'src/app/registration/auth-gaurd.service';

@Component({
  selector: 'app-login-member',
  templateUrl: './login-member.component.html',
  styleUrls: ['./login-member.component.css']
})
export class LoginMemberComponent implements OnInit {
  message:any
  messageAdmin:any
  showModal: boolean;
  
  isAdmin: boolean = false;
  submitted = false;

  Loginform:FormGroup;
  constructor(private fb: FormBuilder, private router: Router, private userService: UserService, private authGaurd: AuthGaurdService)  { }
  

  ngOnInit() {
    this.Loginform=this.fb.group({
      memberEmailid:['',Validators.required],
      memberPassword:['',Validators.required]
    });
    
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.Loginform.invalid) {
        return;
    }
    if(this.submitted)
    {
      this.userService.authenticateMember(this.Loginform).subscribe(
        data => {
          console.log(data['user'])
          console.log("approved");
         
          this.userService.member = true
          this.userService.admin = false
          this.userService.superUser = false;
          console.log(this.userService.admin);
          this.userService.user = data['user']
          console.log(this.userService.user);
          if(data['message']=="Logged In Successfully")
          {
            this.message=data['message'];
            console.log(this.userService.user['memberFirstname'])
            console.log("logged in succesfully");
            this.router.navigateByUrl('/memberClaims/'+this.userService.user['memberId']);
          }
          else if(data['message']=="User not approved"){
            this.userService.member = false;
            this.userService.admin = false;
            this.userService.superUser = false;
            this.message=data['message'];
            console.log(this.message)
            this.messageAdmin =this.userService.user['memberRejMessage'];
            console.log(this.messageAdmin)
            this.userService.user = null;
          }
          else
          {
            this.userService.member = false
            this.userService.admin = false
            this.userService.superUser = false
            this.message=data['message'];
            this.messageAdmin = data['message'];
            this.userService.user = null;
        
          }
        },
        error => console.log(error)
      )
      this.showModal = false;
    }
   
}
}
