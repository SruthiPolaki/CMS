import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/registration/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  ismember:boolean
  constructor(private userService:UserService) { }

  ngOnInit() {
  }
  isMember(){
    return this.userService.member
  }
  isAdmin()
  {
    return this.userService.admin
  }

  isSuperUser()
  {
    return this.userService.superUser
  }

  createClaim()
  {

  }
  checkClaimStatus(){
    
  }
  reSubmitClaim(){
    
  }
  getUser()
  {
    return this.userService.user
  }
  onLogout()
  {
    this.userService.user = null
    this.userService.logout();
  }
}
