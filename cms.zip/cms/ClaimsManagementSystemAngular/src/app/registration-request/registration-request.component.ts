import { Component, OnInit } from '@angular/core';
import { UserService } from '../registration/user.service';
import { Observable } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration-request',
  templateUrl: './registration-request.component.html',
  styleUrls: ['./registration-request.component.css']
})
export class RegistrationRequestComponent implements OnInit {
  message:any
  rejectClick:boolean=false;
  memberRegistrations:Observable<any[]>
  commentForm:FormGroup
  isMemberViewed:boolean =false;
  memberDetails:any

  constructor(private userService:UserService,private fb:FormBuilder) { }

  ngOnInit() {
    this.memberRegistrations = (this.userService.requestDetails())
    console.log(this.memberRegistrations)
    this.commentForm = this.fb.group({
      reject:['',Validators.required]
    })
  }

  viewMemberDetails(id:number)
  {
    console.log("success");
    console.log(id);
    this.isMemberViewed=true;
    console.log(this.isMemberViewed);
    this.userService.viewMemberDetailsById(id).subscribe(
      data=>{
        console.log(data)
        this.memberDetails=data;
        console.log(this.memberDetails['memberId']);
      }
    )   
  }

  acceptNewMember(id:number)
  {
    console.log("Accept Method Activated");
    console.log(id);
    this.userService.acceptMember(id,true).subscribe(
      data => {
      console.log(JSON.parse(JSON.stringify(data))['message'])
      this.memberRegistrations = this.userService.requestDetails()
      this.isMemberViewed=false;
      }
    )
  }

onReject(id:number)
{

  console.log("on Reject");
 this.message = this.commentForm.get('reject').value
 console.log(this.message);
 this.userService.rejectMember(id,false,this.message).subscribe(
   data => {
    console.log(JSON.parse(JSON.stringify(data))['message'])
    this.memberRegistrations = this.userService.requestDetails()
    this.isMemberViewed=false;
   }
 )

}

}
