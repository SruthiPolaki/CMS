import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-member-approval',
  templateUrl: './member-approval.component.html',
  styleUrls: ['./member-approval.component.css']
})



export class MemberApprovalComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
    
  }
  onAgentClick(){
  this.router.navigateByUrl("memberRequest");
  }

  onClaimsClick(){
    this.router.navigateByUrl("memberClaimsRequest");
  }

}
