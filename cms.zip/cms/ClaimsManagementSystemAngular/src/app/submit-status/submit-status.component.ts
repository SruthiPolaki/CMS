import { Component, OnInit } from '@angular/core';
import { UserService } from '../registration/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-submit-status',
  templateUrl: './submit-status.component.html',
  styleUrls: ['./submit-status.component.css']
})
export class SubmitStatusComponent implements OnInit {
  claimId: number
  submitClaim:boolean = false;
  reSubmitClaim:boolean = false;

  constructor(private userservice:UserService,private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
    this.claimId = this.activatedRoute.snapshot.params['claimId'] as number
    this.submitClaim = this.userservice.submit1;
    this.reSubmitClaim = this.userservice.resubmit;
  }

}
