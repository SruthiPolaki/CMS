import { Component, OnInit } from '@angular/core';
import { UserService } from '../registration/user.service';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-claim-status',
  templateUrl: './claim-status.component.html',
  styleUrls: ['./claim-status.component.css']
})
export class ClaimStatusComponent implements OnInit {
  memId:number
  message:any
  memberClaims:Observable<any[]>;
  constructor(private userService:UserService,private activatedRoute:ActivatedRoute) { }

  ngOnInit() { 
    console.log(this.userService.user['memberId'])
    
    console.log("entered")
    this.userService.getClaimStatus(this.userService.user['memberId']).subscribe(
      data => {
        this.message=data['message']
        console.log(data)
        
        this.memberClaims = data['claims']
        if(this.memberClaims==null)
        {
          this.memberClaims=null
        }
        console.log(this.memberClaims)
      }
    )
  
  }

}
